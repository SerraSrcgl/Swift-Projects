//
//  ViewController.swift
//  Leaks
//
//  Created by Serra Saracoglu on 11/04/2021.
//

import UIKit

class ViewController: UIViewController {
    
    var object1:Int?=10
    

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.rightBarButtonItem=UIBarButtonItem(title: "SHOW RED", style: .plain, target: self, action: #selector(handleShowRedController))
        
        let object2=object1
        object1=nil
        print(object2)
        
        
        
        // Do any additional setup after loading the view.
    }
    @objc func handleShowRedController(){
        navigationController?.pushViewController(RedController(), animated: true)
    }
    class Service{
        var redController:RedController?
        
    }
    //I created a class firstly 
    
    class RedController:UITableViewController{
        deinit {
            print("OS reclaiming memory")
        }
        
        let service=Service()
        override func viewDidLoad() {
            super.viewDidLoad()
            tableView.backgroundColor = .red
            
            service.redController=self
        }
    }
    
}

